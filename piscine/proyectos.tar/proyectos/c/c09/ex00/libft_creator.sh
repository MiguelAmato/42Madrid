#!/bin/bash

rm -f libft.a
gcc -c -Wall -Wextra -Werror ft_putchar.c ft_putstr.c ft_strcmp.c ft_strlen.c ft_swap.c
ar rcs libft.a *.o
rm -f *.o